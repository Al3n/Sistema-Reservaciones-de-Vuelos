package reservaciones.pantallas;

import javax.swing.*;
import java.awt.*;

public class PantallaPrincipal extends PantallaFrame {

  public PantallaPrincipal (InterfaceUsuario ui) {
    super(ui);
  }
  public void crearPantalla() {

    panel = new JPanel();
    panel.setLayout(new GridLayout(3,1));
    panel.add(new JLabel("SISTEMA DE RESERVACIONES DE VUELO", JLabel.CENTER));
    panel.add(new JLabel("Pantalla Principal (P-1)", JLabel.CENTER));
    paneles.addElement(panel);

    panel = new JPanel();
    panel.setLayout(new GridLayout(4,1));//5 fila, 1 cols
    panel.add(new JLabel("Servicios Ofrecidos:", JLabel.CENTER));
    panel.add(new JLabel("* Consulta de Vuelos, Tarifas y Horarios", JLabel.CENTER));
    panel.add(new JLabel("* Reserva de Vuelos", JLabel.CENTER));
    panel.add(new JLabel("* Compra de Boletos", JLabel.CENTER));
    paneles.addElement(panel);

    panel = new JPanel();
    panel.setLayout(new GridLayout(1,1));
    panel.add(new JLabel("Para registrarse por primera vez oprima:", JLabel.CENTER));
    paneles.addElement(panel);

    panel = new JPanel();
    boton = new JButton ("Registrarse por Primera Vez");
    botones.addElement(boton);
    panel.add(boton);
    paneles.addElement(panel);

    panel = new JPanel();
    panel.setLayout(new GridLayout(1,1));
    panel.add(new JLabel("Para accesar todos los servicios de vuelo (consulta, reserva, compra) o modificar su registro, oprima:", JLabel.CENTER));
    paneles.addElement(panel);

    panel = new JPanel();
    panel.add(new JLabel("Login:", JLabel.LEFT));
    panel.add(new JTextField(20));
    paneles.addElement(panel);

    panel = new JPanel();
    panel.add(new JLabel("Password:"));
    panel.add(new JTextField(20));
    //   campo.setEchoChar('#');
    paneles.addElement(panel);

    panel = new JPanel();
    boton = new JButton("OK");
    botones.addElement(boton);
    panel.add(boton);

    boton = new JButton("Salir");
    botones.addElement(boton);
    panel.add(boton);
    paneles.addElement(panel);
  }
  public Pantalla manejarEvento(String str) {
    if (str.equals("Registrarse por Primera Vez")) {
         pantalla = new PantallaCrearRegUsuario(interfaceUsuario);
      return pantalla;
    }
    else if (str.equals("OK")) {
         pantalla = new PantallaServicio(interfaceUsuario);
      return pantalla;
    }
    else if (str.equals("Salir")) {
      System.exit(0);
    }
    else
      System.out.println("Error en PantallaPrincipal: "+str);

    return this;
  }
}