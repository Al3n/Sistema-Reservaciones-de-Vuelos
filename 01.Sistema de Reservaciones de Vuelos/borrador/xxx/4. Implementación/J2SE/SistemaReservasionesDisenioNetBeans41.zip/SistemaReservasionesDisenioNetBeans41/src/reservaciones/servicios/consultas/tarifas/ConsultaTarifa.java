/*
 * ConsultaTarifa.java
 *
 */

package reservaciones.servicios.consultas.tarifas;

/**
 *
 */
public class ConsultaTarifa {
    
    /** Creates a new instance of ConsultaTarifa */
    public ConsultaTarifa() {
    }
    
}
