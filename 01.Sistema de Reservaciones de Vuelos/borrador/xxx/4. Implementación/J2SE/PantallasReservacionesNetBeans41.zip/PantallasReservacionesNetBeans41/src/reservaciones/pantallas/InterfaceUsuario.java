package reservaciones.pantallas;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class InterfaceUsuario extends JFrame implements ActionListener
{
  private Pantalla pantalla;
  
  public InterfaceUsuario() {
    setSize(800,600);
    setBackground(Color.lightGray);
    pantalla = new PantallaPrincipal(this);
    desplegarPantalla(pantalla);
  }
  public void actionPerformed(ActionEvent event) {
    System.out.println("Action: "+event.getActionCommand());
    if (pantalla != null)
      pantalla = pantalla.manejarEvento(event.getActionCommand());
    desplegarPantalla(pantalla);
  }

  public void desplegarPantalla(Pantalla p) {
    if (p != null) {
        p.borrarPantalla(); 
        p.refrescarPantalla();
	setVisible(true);
    }
    else
        System.out.println("Pantalla Nula");
  }
  public static void main(String[] args) {
    System.out.println("Starting System...");
    InterfaceUsuario iu = new InterfaceUsuario();
  }
}
