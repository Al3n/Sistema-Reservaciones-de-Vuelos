//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\interfaceUsuario\\InterfaceUsuario.java

package reservaciones.interfaceUsuario;


public class InterfaceUsuario 
{
   
   /**
   @roseuid 401EF52803D8
    */
   public InterfaceUsuario() 
   {
    
   }
}
