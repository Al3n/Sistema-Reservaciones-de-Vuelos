package reservaciones.interfaceUsuarioServlet;

import reservaciones.interfaceUsuario.*;

import reservaciones.principal.*;
import reservaciones.dominio.*;
import reservaciones.util.*;

public class InterfaceUsuarioBean extends InterfaceUsuario
{
    private String showPantalla;
    private ObjetoEntidad beanDatos;
    private ReservacionesServlet servlet;

    public InterfaceUsuarioBean() {
        inicializar();
    }
  public Pantalla crearPantalla(String classpath,String classname) {
    pantalla = (Pantalla) Utilerias.instanciarClase("reservaciones.interfaceUsuario.Pantalla");
    pantalla.setInterfaceUsuario(this);
    pantalla.escribirNombre(classname);
    return pantalla;
  }
  public void desplegarPantalla(String str) {
    showPantalla = str + ".jsp";
  }
  public void desplegarPantalla(Pantalla p) {
    if (p != null)
        pantalla = p;

    showPantalla = pantalla.leerNombre() + ".jsp";
  }
  public void escribirElementos(Pantalla p, Datos datos) {
	beanDatos = datos;
  }
  public void escribirElementos(Pantalla p, DatosMultiples datos) {
	beanDatos = datos;
  }
/**
 * Insert the method's description here.
 * Creation date: (10/24/2002 11:17:47 AM)
 * @return reservaciones.dominio.Datos
 */
public ObjetoEntidad getDatos() {
	return beanDatos;
}
/**
 * Insert the method's description here.
 * Creation date: (12/17/2002 11:30:48 AM)
 * @return reservaciones.interfaceUsuario.ReservacionesServlet
 */
public ReservacionesServlet getServlet() {
	return servlet;
}
/**
 * Insert the method's description here.
 * Creation date: (12/11/2002 1:15:15 PM)
 * @return java.lang.String
 */
public String getShowPantalla() {
	return showPantalla;
}
/**
 * Insert the method's description here.
 * Creation date: (10/3/2001 1:30:25 PM)
 */
public void inicializar() {
	manejador = new ManejadorPrincipal(this,false); // false - servlet
}
/**
 * Insert the method's description here.
 * Creation date: (12/17/2002 12:08:12 PM)
 * @return java.lang.String
 * @param name java.lang.String
 */
public int numeroDatos(){
    int i = 0;
    if (beanDatos != null)
    	i = beanDatos.numeroDatos();
    else
    	System.out.println("Datos nulos");
    return i;
}
public String leerDatos(String name,int i) {
    String str = null;
    if (beanDatos != null)
    	str = beanDatos.leerValor(name,i);
    else
    	System.out.println("Datos nulos");
    if (str == null)
    	str = "";
    return str;
}
public String leerDatos(String name) {
    String str = null;
    if (beanDatos != null)
    	str = beanDatos.leerValor(name);
    else
    	System.out.println("Datos nulos");
    if (str == null)
    	str = "";
    return str;
}
/**
 * Insert the method's description here.
 * Creation date: (12/11/2002 5:33:59 PM)
 * @param p reservaciones.interfaceUsuario.Pantalla
 * @param datos reservaciones.dominio.Datos
 */
public void leerElementos(Pantalla p, Datos datos) {
	if (servlet != null)
		servlet.leerElementos(datos);
/*	String str;
    for (int i = 0; i < datos.numeroAtributos(); i++) {
      str = pDatos.leerValor(i);
      datos.escribirValor(i,str);
    }*/
}
/**
 * Insert the method's description here.
 * Creation date: (12/17/2002 11:30:12 AM)
 * @param rs reservaciones.interfaceUsuario.ReservacionesServlet
 */
public void setServlet(ReservacionesServlet rs) {
	servlet = rs;
}

/**
 * Insert the method's description here.
 * Creation date: (12/11/2002 5:35:55 PM)
 * @return java.lang.String
 * @param name java.lang.String
 */
public String leerTexto(Pantalla p, String name) {
	String str = null;
	if (servlet != null)
		str = servlet.leerTexto(name);
	return str;
}
}
