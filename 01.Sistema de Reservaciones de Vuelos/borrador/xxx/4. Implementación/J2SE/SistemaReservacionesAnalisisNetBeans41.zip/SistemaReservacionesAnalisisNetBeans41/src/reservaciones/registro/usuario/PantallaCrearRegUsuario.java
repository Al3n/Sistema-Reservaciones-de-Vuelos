//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\registro\\usuario\\PantallaCrearRegUsuario.java

package reservaciones.registro.usuario;


public class PantallaCrearRegUsuario 
{
   
   /**
   @roseuid 401EF4C4007D
    */
   public PantallaCrearRegUsuario() 
   {
    
   }
}
