//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\servicios\\dominio\\ViajeroFrecuente.java

package reservaciones.servicios.dominio;


public class ViajeroFrecuente 
{
   
   /**
   @roseuid 401EF83E0196
    */
   public ViajeroFrecuente() 
   {
    
   }
}
