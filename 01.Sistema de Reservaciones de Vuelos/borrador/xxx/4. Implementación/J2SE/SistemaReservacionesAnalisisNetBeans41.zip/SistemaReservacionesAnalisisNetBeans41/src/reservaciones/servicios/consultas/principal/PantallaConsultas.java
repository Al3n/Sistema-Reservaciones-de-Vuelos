//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\servicios\\consultas\\PantallaConsultas.java

package reservaciones.servicios.consultas;


public class PantallaConsultas 
{
   
   /**
   @roseuid 401EF4C603D8
    */
   public PantallaConsultas() 
   {
    
   }
}
