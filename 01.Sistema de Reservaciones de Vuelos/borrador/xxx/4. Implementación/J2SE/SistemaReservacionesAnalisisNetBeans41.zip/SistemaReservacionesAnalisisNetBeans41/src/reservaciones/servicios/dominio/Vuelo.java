//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\servicios\\dominio\\Vuelo.java

package reservaciones.servicios.dominio;


public class Vuelo 
{
   
   /**
   @roseuid 401EF83B03B9
    */
   public Vuelo() 
   {
    
   }
}
