//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\servicios\\consultas\\estado\\PantallaResultadoEstado.java

package reservaciones.servicios.consultas.estado;


public class PantallaResultadoEstado 
{
   
   /**
   @roseuid 401EF4C802CE
    */
   public PantallaResultadoEstado() 
   {
    
   }
}
