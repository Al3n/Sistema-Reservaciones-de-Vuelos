package reservaciones.servicios.dominio;


public class Horario 
{
   public Horario() 
   {
    
   }
}
