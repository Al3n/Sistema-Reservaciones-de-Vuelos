package reservaciones.servicios.dominio;


public class Pasajero 
{
   public Pasajero() 
   {
    
   }
}
