package reservaciones.registro.interfaceBD;

import reservaciones.dominio.*;
import reservaciones.registro.usuario.*;
import reservaciones.registro.tarjeta.*;
import java.sql.*;
import java.util.*;
import java.awt.*;

public class InterfaceBaseDatosRegistro extends InterfaceRegistro
{
    public InterfaceBaseDatosRegistro()
    {
    }
    public boolean actualizarRegistro(Datos reg)
    {
        return true;
    }
    public boolean crearRegistro(Datos reg)
    {
        return true;
    }
    public boolean eliminarRegistro(Datos reg)
    {
        return true;
    }
    public boolean obtenerRegistro(Datos reg,String log)
    {
        return true;
    }
    public boolean validarRegistro(Datos reg,String log, String pass) 
    {
        return true;
    }
}