package reservaciones.servicios.dominio;


public class Asiento 
{
   public Asiento() 
   {
    
   }
}
