//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\servicios\\interfaceBD\\InterfaceBaseDatosReserva.java

package reservaciones.servicios.interfaceBD;


public class InterfaceBaseDatosReserva 
{
   
   /**
   @roseuid 401EFB61000F
    */
   public InterfaceBaseDatosReserva() 
   {
    
   }
}
