//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\servicios\\consultas\\estado\\PantallaConsultaEstado.java

package reservaciones.servicios.consultas.estado;


public class PantallaConsultaEstado 
{
   
   /**
   @roseuid 401EF4C801F4
    */
   public PantallaConsultaEstado() 
   {
    
   }
}
