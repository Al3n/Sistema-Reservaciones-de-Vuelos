//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\servicios\\ManejadorServicio.java

package reservaciones.servicios.principal;


public class ManejadorServicio 
{
   
   /**
   @roseuid 401EF4C501F4
    */
   public ManejadorServicio() 
   {
    
   }
}
