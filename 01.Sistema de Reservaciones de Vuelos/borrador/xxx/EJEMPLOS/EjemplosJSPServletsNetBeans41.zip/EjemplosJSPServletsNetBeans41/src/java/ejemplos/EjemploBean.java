/*
 * EjemploBean.java
 *
 * Created on 6 de enero de 2005, 12:15 PM
 */

package ejemplos;

/**
 *
 * @author Administrador
 */
public class EjemploBean {
    
  private int filas = 1;
  private int columnas = 1;

  public int getFilas() {
    return filas;
  }

  public int getColumnas() {
    return columnas;
  }

  public void setFilas(int n) {
    filas = n;
  }

  public void setColumnas(int n) {
    columnas = n;
  }
    
}
