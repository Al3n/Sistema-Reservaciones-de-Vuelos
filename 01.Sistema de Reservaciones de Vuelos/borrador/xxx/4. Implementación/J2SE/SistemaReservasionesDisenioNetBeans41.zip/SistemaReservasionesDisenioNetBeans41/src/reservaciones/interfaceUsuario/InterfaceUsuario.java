package reservaciones.interfaceUsuario;

import java.awt.*;
import java.awt.event.*;

import reservaciones.principal.*;
import reservaciones.dominio.*;

public abstract class InterfaceUsuario {
    
  	protected Manejador manejador;
  	protected Pantalla pantalla;
/**
 * Insert the method's description here.
 * Creation date: (10/24/2002 11:34:20 AM)
 */
public InterfaceUsuario() {}
  public InterfaceUsuario(Manejador m) {
    manejador = m;
  }
/**
 * Insert the method's description here.
 * Creation date: (10/23/2002 6:25:57 PM)
 * @param claspath java.lang.String
 * @param classname java.lang.String
 */
public abstract Pantalla crearPantalla(String claspath, String classname);
  // Contrato 1: Desplegar Pantalla
  public abstract void desplegarPantalla(Pantalla p);
/**
 * Insert the method's description here.
 * Creation date: (12/11/2002 12:53:00 PM)
 */
public void enviarEvento(String evento) {
	System.out.println("InterfaceUsuario Evento: "+evento);
    if (manejador != null)
      manejador.manejarEvento(evento);
    else
      System.out.println("Manejador nulo");
}

public void inicializar() {}

  // Otros metodos
  // public void setPantalla (Pantalla p) { pantalla = p; }
  public void setManejador (Manejador m) { manejador = m; }
}