package reservaciones.pantallas;

import javax.swing.*;
import java.awt.*;

public class PantallaServicio extends PantallaFrame {

  public PantallaServicio(InterfaceUsuario ui) {
    super(ui); }
  public void crearPantalla() {

    panel = new JPanel();
    panel.setLayout(new GridLayout(3,1));
    panel.add(new JLabel("SISTEMA DE RESERVACIONES DE VUELO", JLabel.CENTER));
    panel.add(new JLabel("Pantalla Servicios (P-2)", JLabel.CENTER));
    paneles.addElement(panel);

    panel = new JPanel();
    panel.add(new JLabel("Presione el tipo de servicio deseado:", JLabel.LEFT));
    paneles.addElement(panel);

    panel = new JPanel();
    boton = new JButton ("Consultar Informacion");
    botones.addElement(boton);
    panel.add(boton);

    boton = new JButton ("Hacer Reservacion");
    botones.addElement(boton);
    panel.add(boton);

    boton = new JButton ("Obtener Registro");
    panel.add(boton);
    botones.addElement(boton);
    paneles.addElement(panel);

    panel = new JPanel();
    agregarBotonesSalir(panel);
  }
  public Pantalla manejarEvento(String str) {
    if (str.equals("Consultar Informacion")){
        pantalla = new PantallaConsultas(interfaceUsuario);
      return pantalla;
    }
    else if (str.equals("Hacer Reservacion")){
        pantalla = new PantallaClaveReservas(interfaceUsuario);
      return pantalla;
    }
    else if (str.equals("Obtener Registro")) {
        pantalla = new PantallaObtenerRegUsuario(interfaceUsuario);
      return pantalla;
    }
    else
      return manejarEventosSalir(str);
  }
}

