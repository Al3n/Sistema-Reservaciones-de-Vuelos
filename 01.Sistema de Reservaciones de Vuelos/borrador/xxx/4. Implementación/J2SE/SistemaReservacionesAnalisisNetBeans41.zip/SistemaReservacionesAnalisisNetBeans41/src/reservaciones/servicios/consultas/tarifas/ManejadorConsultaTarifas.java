//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\servicios\\consultas\\tarifas\\ManejadorConsultaTarifas.java

package reservaciones.servicios.consultas.tarifas;


public class ManejadorConsultaTarifas 
{
   
   /**
   @roseuid 401EF4CB032C
    */
   public ManejadorConsultaTarifas() 
   {
    
   }
}
