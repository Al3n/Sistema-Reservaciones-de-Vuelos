package reservaciones.pantallas;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class PanelTabla extends PanelData {

    private JScrollPane scrollPane;

    public PanelTabla(JTable jt) {
        super(jt);
    }
    public PanelTabla(JPanel p,String str,int x,int y, String[] nombreColumnas) {
        super(p,str);
        int lenColumnas = nombreColumnas.length;
        int lenFilas = 10;
        String[][] datos = new String[lenFilas][lenColumnas];
        comp = new JTable(datos, nombreColumnas);
        comp.setName(str);
        ((JTable) comp).setPreferredScrollableViewportSize(new Dimension(x, y));
        scrollPane = new JScrollPane(comp);
        p.add(scrollPane);
     }
}