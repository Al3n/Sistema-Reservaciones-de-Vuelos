//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\servicios\\dominio\\Reservacion.java

package reservaciones.servicios.dominio;


public class Reservacion 
{
   
   /**
   @roseuid 401EF83C00DA
    */
   public Reservacion() 
   {
    
   }
}
