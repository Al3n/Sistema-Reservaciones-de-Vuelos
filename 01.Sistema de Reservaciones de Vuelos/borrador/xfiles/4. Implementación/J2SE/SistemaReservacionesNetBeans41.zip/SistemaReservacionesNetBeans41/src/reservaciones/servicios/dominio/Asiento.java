//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\servicios\\dominio\\Asiento.java

package reservaciones.servicios.dominio;


public class Asiento 
{
   
   /**
   @roseuid 401EF83D0251
    */
   public Asiento() 
   {
    
   }
}
