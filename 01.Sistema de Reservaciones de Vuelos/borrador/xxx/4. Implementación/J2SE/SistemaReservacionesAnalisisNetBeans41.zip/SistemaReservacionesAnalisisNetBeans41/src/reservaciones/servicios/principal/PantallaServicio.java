//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\servicios\\PantallaServicio.java

package reservaciones.servicios.principal;


public class PantallaServicio 
{
   
   /**
   @roseuid 401EF4C502CE
    */
   public PantallaServicio() 
   {
    
   }
}
