//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\servicios\\dominio\\Aerolinea.java

package reservaciones.servicios.dominio;


public class Aerolinea 
{
   
   /**
   @roseuid 401EF83C02FD
    */
   public Aerolinea() 
   {
    
   }
}
