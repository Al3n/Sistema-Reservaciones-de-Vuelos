/*
 * ResultadoEstado.java
 *
 */

package reservaciones.servicios.consultas.estado;

/**
 *
 */
public class ResultadoEstado {
    
    /** Creates a new instance of ResultadoEstado */
    public ResultadoEstado() {
    }
    
}
