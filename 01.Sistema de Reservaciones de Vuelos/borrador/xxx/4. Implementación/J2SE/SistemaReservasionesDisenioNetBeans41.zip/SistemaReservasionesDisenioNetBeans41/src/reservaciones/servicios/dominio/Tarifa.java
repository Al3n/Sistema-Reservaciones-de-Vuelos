//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\servicios\\dominio\\Tarifa.java

package reservaciones.servicios.dominio;


public class Tarifa 
{
   
   /**
   @roseuid 401EF83D0138
    */
   public Tarifa() 
   {
    
   }
}
