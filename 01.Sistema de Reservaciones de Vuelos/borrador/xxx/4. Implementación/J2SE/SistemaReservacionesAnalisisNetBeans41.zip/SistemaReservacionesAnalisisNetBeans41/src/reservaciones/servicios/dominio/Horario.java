//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\servicios\\dominio\\Horario.java

package reservaciones.servicios.dominio;


public class Horario 
{
   
   /**
   @roseuid 401EF83C01E4
    */
   public Horario() 
   {
    
   }
}
