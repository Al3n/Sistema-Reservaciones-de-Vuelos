//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\servicios\\dominio\\Aeropuerto.java

package reservaciones.servicios.dominio;


public class Aeropuerto 
{
   
   /**
   @roseuid 401EF83D002E
    */
   public Aeropuerto() 
   {
    
   }
}
