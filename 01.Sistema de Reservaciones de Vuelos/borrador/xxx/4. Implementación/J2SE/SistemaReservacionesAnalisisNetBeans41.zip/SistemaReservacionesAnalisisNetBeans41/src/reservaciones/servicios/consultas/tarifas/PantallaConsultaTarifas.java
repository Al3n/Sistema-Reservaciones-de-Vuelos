//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\servicios\\consultas\\tarifas\\PantallaConsultaTarifas.java

package reservaciones.servicios.consultas.tarifas;


public class PantallaConsultaTarifas 
{
   
   /**
   @roseuid 401EF4CC001F
    */
   public PantallaConsultaTarifas() 
   {
    
   }
}
