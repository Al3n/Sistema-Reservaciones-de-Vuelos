package reservaciones.registro.tarjeta;

import reservaciones.dominio.*;

public class RegistroTarjeta extends Datos {

    public RegistroTarjeta() {

    }
}