//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\servicios\\dominio\\Pasajero.java

package reservaciones.servicios.dominio;


public class Pasajero 
{
   
   /**
   @roseuid 401EF83D035B
    */
   public Pasajero() 
   {
    
   }
}
