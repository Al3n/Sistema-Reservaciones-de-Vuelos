package reservaciones.pantallas;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 *
 * @author alfredow
 */
public class PanelTexto extends PanelData {
   public PanelTexto(JPanel p,String str, int length){
      super(p,str);
      comp = new JTextField(length);
      comp.setName(name);
      p.add(comp);
   }
   public PanelTexto(JTextField jc){
       super(jc);
   }
}