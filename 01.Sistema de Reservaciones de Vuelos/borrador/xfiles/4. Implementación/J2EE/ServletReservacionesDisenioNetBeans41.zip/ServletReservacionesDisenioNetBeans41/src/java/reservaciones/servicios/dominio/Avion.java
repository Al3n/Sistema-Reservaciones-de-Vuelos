package reservaciones.servicios.dominio;


public class Avion 
{
   public Avion() 
   {
    
   }
}
