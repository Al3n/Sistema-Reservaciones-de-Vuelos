/*
 * ResultadoHorario.java
 *
 */

package reservaciones.servicios.consultas.horarios;

import reservaciones.dominio.*;

public class ResultadoHorario extends Datos {
    
    /** Creates a new instance of ResultadoHorario */
    public ResultadoHorario() {
    }
    
}
