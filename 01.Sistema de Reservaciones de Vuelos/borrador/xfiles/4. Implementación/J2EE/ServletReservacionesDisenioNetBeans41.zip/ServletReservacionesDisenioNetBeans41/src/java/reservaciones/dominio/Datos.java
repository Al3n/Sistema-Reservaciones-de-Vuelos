package reservaciones.dominio;

import java.util.*;

public abstract class Datos {

  public Datos() {
  }
}