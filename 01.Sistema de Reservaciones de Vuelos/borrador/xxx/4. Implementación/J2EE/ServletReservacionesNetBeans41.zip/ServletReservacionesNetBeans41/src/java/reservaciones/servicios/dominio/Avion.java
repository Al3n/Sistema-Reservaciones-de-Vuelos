//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\servicios\\dominio\\Avion.java

package reservaciones.servicios.dominio;


public class Avion 
{
   
   /**
   @roseuid 401EF83E008C
    */
   public Avion() 
   {
    
   }
}
