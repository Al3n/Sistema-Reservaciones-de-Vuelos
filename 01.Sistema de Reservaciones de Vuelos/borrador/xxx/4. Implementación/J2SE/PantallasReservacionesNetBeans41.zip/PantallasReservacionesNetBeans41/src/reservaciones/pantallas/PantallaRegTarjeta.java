package reservaciones.pantallas;

import javax.swing.*;
import java.awt.*;

public class PantallaRegTarjeta extends PantallaFrame {

  public PantallaRegTarjeta(InterfaceUsuario ui) {
    super (ui); }
  public void crearPantalla() {
    panel = new JPanel();
    panel.add(new Label("Nombre:", Label.LEFT));
    panel.add(new JTextField(40));
    paneles.addElement(panel);

    panel = new JPanel();
    panel.add(new Label("Numero de Tarjeta (requerido para pagos):"));
    panel.add(new JTextField(20));
    paneles.addElement(panel);

    panel = new JPanel();
    panel.add(new Label("Tipo"));
    panel.add(new JTextField(20));
    panel.add(new Label("Fecha Vencimiento"));
    panel.add(new JTextField(20));
    paneles.addElement(panel);
  }
}
