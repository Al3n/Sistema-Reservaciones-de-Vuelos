//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\servicios\\consultas\\horarios\\PantallaConsultaHorarios.java

package reservaciones.servicios.consultas.horarios;


public class PantallaConsultaHorarios 
{
   
   /**
   @roseuid 401EF4CA0119
    */
   public PantallaConsultaHorarios() 
   {
    
   }
}
