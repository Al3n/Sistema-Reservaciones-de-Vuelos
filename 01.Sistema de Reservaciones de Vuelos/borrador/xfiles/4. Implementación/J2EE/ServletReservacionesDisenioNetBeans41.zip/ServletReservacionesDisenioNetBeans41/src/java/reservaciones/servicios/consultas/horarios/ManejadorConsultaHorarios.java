package reservaciones.servicios.consultas.horarios;

import reservaciones.principal.*;
import reservaciones.interfaceUsuario.*;
import reservaciones.servicios.consultas.*;
import reservaciones.servicios.interfaceBD.*;
import reservaciones.registro.interfaceBD.*;
import reservaciones.servicios.dominio.*;
import reservaciones.dominio.*;

public class ManejadorConsultaHorarios extends Manejador {
    
        private Pantalla pantallaConsultaHorarios;
        private Pantalla pantallaResultadoHorarios;
        private InterfaceReserva interfaceBD;
        private ConsultaHorario consultaHorario;
        private ResultadoHorario resultadoHorario;
        private Aeropuertos aeropuerto;
        
        public ManejadorConsultaHorarios(Manejador m,InterfaceUsuario ui) {
                super(m,ui);
    		if (interfaceBD == null)
                        interfaceBD = new InterfaceBaseDatosReserva();
  }
  // Contrato 1: Manejar Evento
  public void manejarEvento(String str) {
    if (str.equals("Consultar"))
      consultarHorarios();
    else if (str.equals("+"))
		   ;
    else if (str.equals("-"))
		   ;
    else if (str.equals("Nueva Consulta"))
       consultar();
    else
      manejarEventosAdicionales(str);
  }
  // Contrato 2: Consultar
  public void consultar() {
      pantallaConsultaHorarios = crearPantalla("PantallaConsultaHorarios");
      desplegarPantalla(pantallaConsultaHorarios);
  }
  // Responsabildiades Privadas
  private void consultarHorarios() {
      pantallaResultadoHorarios = crearPantalla("PantallaResultadoHorarios");
      consultaHorario = new ConsultaHorario();
      if (interfaceBD != null)
            interfaceBD.consultarHorario();
      desplegarPantalla(pantallaResultadoHorarios);
  }
}


