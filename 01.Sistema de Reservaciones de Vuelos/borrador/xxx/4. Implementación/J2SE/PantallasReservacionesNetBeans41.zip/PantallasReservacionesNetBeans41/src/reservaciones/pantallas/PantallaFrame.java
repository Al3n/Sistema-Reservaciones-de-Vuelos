package reservaciones.pantallas;

import java.util.*;
import java.awt.*;
import javax.swing.*;

public class PantallaFrame extends Pantalla {
    
  protected Pantalla pantalla;
  protected InterfaceUsuario interfaceUsuario;
  protected Vector<JPanel> paneles;
  protected Vector<JButton> botones;
  protected Vector<PanelData> campos;
  protected JPanel panel;
  protected JButton boton;
  protected PanelData campo;
  
  protected PantallaFrame(InterfaceUsuario ui) {
    interfaceUsuario = ui;
    inicializarPantalla();
    crearPantalla();
  }
  
  public void setInterfaceUsuario(InterfaceUsuario iu) { interfaceUsuario = iu; }

  protected void inicializarPantalla() {
    paneles = new Vector<JPanel>();
    botones = new Vector<JButton>();
    campos = new Vector<PanelData>();
   }
  protected void agregarBotonesSalir(JPanel panel){
    boton = new JButton ("Salir");
    panel.add(boton);
    botones.addElement(boton);
    paneles.addElement(panel);
  }
  protected void agregarBotonesServiciosSalir(JPanel panel){

    boton = new JButton ("Servicios");
    botones.addElement(boton);
    panel.add(boton);

    agregarBotonesSalir(panel);
  }
  protected Pantalla manejarEventosServiciosSalir(String str) {
    if (str.equals("Servicios")) {
         pantalla = new PantallaServicio(interfaceUsuario);
      return pantalla;
    }
    else
      manejarEventosSalir(str);

    return this; // null;
  }
  protected Pantalla manejarEventosSalir(String str) {
    if (str.equals("Salir"))
      System.exit(0);
    else
      System.out.println("Error en boton: "+str);

    return this; // null;
  }
  public void borrarPantalla() {
    interfaceUsuario.getContentPane().removeAll();
    int bs = botones.size();
    for (int i = 0; i < bs; i++)
    if ((boton = (JButton)botones.elementAt(i)) != null)
      boton.removeActionListener(interfaceUsuario);
  }
  // crear elementos pantalla
  public void crearPantalla() { }
  protected JPanel getPanel(String pname) {
    JPanel p = null;
    int ps = paneles.size();
    String name = null;
    for (int i = 0; name.equals(pname) == false && i < ps; i++){
      p = (JPanel) paneles.elementAt(i);
      name = p.getName();
      if (name.equals(pname) == true)
          break;
    }
    return p;
  }
  protected int getPanelIndex(String pname) {
    JPanel p = null;
    int ps = paneles.size();
    String name = null;
    if (pname == null)
        return -1;
    int i = 0;
    for (i = 0; pname.equals(name) == false && i < ps; i++){
      p = (JPanel) paneles.elementAt(i);
      name = p.getName();
      if (pname.equals(name) == true)
          break;
    }
    return i;
  }
  // Contrato 1: Desplegar Pantalla
  protected void desplegarPantalla() {
    System.out.println("Desplegando: "+ this);
    int ps = paneles.size();
    interfaceUsuario.getContentPane().setLayout(new GridLayout(ps,1));
    for (int i = 0; i < ps; i++)
      interfaceUsuario.getContentPane().add((JComponent)paneles.elementAt(i));
    int bs = botones.size();
    for (int i = 0; i < bs; i++)
      if ((boton = (JButton)botones.elementAt(i)) != null)
        boton.addActionListener(interfaceUsuario);
  }
  public void refrescarPantalla() {
    System.out.println("Desplegando: "+ this);
    int ps = paneles.size();
    interfaceUsuario.getContentPane().setLayout(new GridLayout(ps,1));
    for (int i = 0; i < ps; i++)
      interfaceUsuario.getContentPane().add((JComponent)paneles.elementAt(i));
    int bs = botones.size();
    for (int i = 0; i < bs; i++)
      if ((boton = (JButton)botones.elementAt(i)) != null)
        boton.addActionListener(interfaceUsuario);
  }

}
