/*
 * ConsultaHorario.java
 *
 */

package reservaciones.servicios.consultas.estado;

/**
 *
 */
public class ConsultaEstado {
    
    /** Creates a new instance of ConsultaHorario */
    public ConsultaEstado() {
    }
    
}
