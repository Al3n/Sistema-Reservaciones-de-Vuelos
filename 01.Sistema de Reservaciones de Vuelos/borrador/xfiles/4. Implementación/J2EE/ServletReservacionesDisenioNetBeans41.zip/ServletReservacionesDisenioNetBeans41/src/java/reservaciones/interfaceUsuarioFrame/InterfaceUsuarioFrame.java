package reservaciones.interfaceUsuarioFrame;

import java.awt.*;
import java.awt.event.*;
import reservaciones.principal.*;
import reservaciones.dominio.*;
import reservaciones.util.*;
import reservaciones.pantallas.*;
import reservaciones.interfaceUsuario.*;

public class InterfaceUsuarioFrame extends InterfaceUsuario {

  private ReservacionesFrame frame;

  public InterfaceUsuarioFrame() {
    frame = new ReservacionesFrame(this);
    manejador = new ManejadorPrincipal(this,true); // true - app
  }
  public Pantalla crearPantalla(String classpath,String classname) {
    pantalla = (Pantalla) Utilerias.instanciarClase(classpath + "." + classname);
    pantalla.setInterfaceUsuario(this);
    pantalla.inicializarInterfaceUsuario();
    return pantalla;
  }
  public void desplegarPantalla(Pantalla p) {
    if (p != null) {
        pantalla = p;
    	if (frame != null)
      		frame.desplegarPantalla(p);
  	}
  	else
        System.out.println("Pantalla Nula");
  }

  public Pantalla getPantalla () { return pantalla; }
  public ReservacionesFrame getReservacionesFrame() { return frame; }

  public static void main(String[] args) {
	System.out.println("Starting System...");
        InterfaceUsuarioFrame iu = new InterfaceUsuarioFrame();
  }
  public void setManejador (Manejador m) { manejador = m; }
  public void setPantalla (Pantalla p) { pantalla = p; }

}
