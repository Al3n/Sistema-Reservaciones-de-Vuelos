package reservaciones.interfaceUsuarioServlet;

import reservaciones.interfaceUsuario.*;

import java.io.*;
import java.net.*;

import javax.servlet.*;
import javax.servlet.http.*;

import reservaciones.dominio.*;

public class ReservacionesServlet extends HttpServlet {
    
     private HttpServletRequest requestActual;
    
    /** Initializes the servlet.
     */
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        
    }
    
    /** Destroys the servlet.
     */
    public void destroy() {
        
    }    
 
    /** Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        response.setContentType("text/html");
        String showPath = "/"; //http://localhost:8080/";
        String showPage = showPath + "PantallaPrincipal.jsp";
        
        String action = request.getParameter("Button");
	System.out.println("Selected Button: "+action);
		
	requestActual = request;
	HttpSession sessionActual = request.getSession(true);

	System.out.println("Starting Session");
	InterfaceUsuarioBean interfaceUsuario = (InterfaceUsuarioBean) sessionActual.getAttribute("interfaceUsuario");

	if (action != null) {
		if (interfaceUsuario != null) {
			if (interfaceUsuario.getServlet() == null) //
				interfaceUsuario.setServlet(this); //
				
			interfaceUsuario.enviarEvento(action);
	  
	   		showPage = showPath + interfaceUsuario.getShowPantalla();
	  		System.out.println("\nshowPage: "+showPage);
		}
	}
	gotoPage(showPage,request, response);	
    }
    
     private void gotoPage(String address,HttpServletRequest request,HttpServletResponse response)
	  throws ServletException, IOException {
	  ServletContext sc = getServletContext();
//      response.sendRedirect(address);
	  RequestDispatcher dispatcher = sc.getRequestDispatcher(address);
	  dispatcher.forward(request, response);
    }
    
    /** Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }
    
    /** Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }
    
    /** Returns a short description of the servlet.
     */
    public String getServletInfo() {
        return "Short description";
    }
}
