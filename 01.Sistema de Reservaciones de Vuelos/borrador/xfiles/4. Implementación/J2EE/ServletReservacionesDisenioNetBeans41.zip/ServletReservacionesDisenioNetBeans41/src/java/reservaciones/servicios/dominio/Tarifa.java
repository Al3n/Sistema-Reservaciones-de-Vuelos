package reservaciones.servicios.dominio;


public class Tarifa 
{
   public Tarifa() 
   {
    
   }
}
