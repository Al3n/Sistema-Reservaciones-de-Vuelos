//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\servicios\\pagos\\ManejadorPagos.java

package reservaciones.servicios.pagos;


public class ManejadorPagos 
{
   
   /**
   @roseuid 401EF4CD0138
    */
   public ManejadorPagos() 
   {
    
   }
}
