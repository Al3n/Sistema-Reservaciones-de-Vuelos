//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\registro\\tarjeta\\ManejadorRegistroTarjeta.java

package reservaciones.registro.tarjeta;


public class ManejadorRegistroTarjeta 
{
   
   /**
   @roseuid 401EF4C2004E
    */
   public ManejadorRegistroTarjeta() 
   {
    
   }
}
