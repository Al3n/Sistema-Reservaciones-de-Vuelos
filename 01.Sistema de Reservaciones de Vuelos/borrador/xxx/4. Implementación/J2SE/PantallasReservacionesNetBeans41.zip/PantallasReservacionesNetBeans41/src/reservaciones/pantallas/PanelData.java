package reservaciones.pantallas;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

public abstract class PanelData {

    protected Vector<JPanel> paneles;
    protected JPanel panel;
    protected int panelIndex;
    protected JComponent comp;
    protected String name;
    
    public PanelData(JPanel p,String str) {
        panel = p;
        name = str;
     }
    public PanelData(JComponent jc) {
        comp = jc;
    }
    public void setPanelIndex(Vector<JPanel> ps,int i){
        paneles = ps;
        panelIndex = i;
    }
}