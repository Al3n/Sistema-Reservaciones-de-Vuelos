package reservaciones.pantallas;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 *
 * @author alfredow
 */
public class PanelComboBox extends PanelData {
   public PanelComboBox(JComboBox jc){
       super(jc);
   }
   public PanelComboBox(JPanel p,String str,String atr){
      super(p,str);
      comp = new JComboBox();
      comp.setName(name);
      p.add(comp);
   } 
}