//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\servicios\\consultas\\horarios\\ManejadorConsultaHorarios.java

package reservaciones.servicios.consultas.horarios;


public class ManejadorConsultaHorarios 
{
   
   /**
   @roseuid 401EF4CA004E
    */
   public ManejadorConsultaHorarios() 
   {
    
   }
}
