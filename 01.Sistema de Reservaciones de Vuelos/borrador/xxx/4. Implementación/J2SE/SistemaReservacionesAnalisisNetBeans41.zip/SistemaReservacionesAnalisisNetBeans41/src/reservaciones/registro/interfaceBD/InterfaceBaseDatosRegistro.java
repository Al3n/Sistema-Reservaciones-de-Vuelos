//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\registro\\interfaceBD\\InterfaceBaseDatosRegistro.java

package reservaciones.registro.interfaceBD;


public class InterfaceBaseDatosRegistro 
{
   
   /**
   @roseuid 401EF4C1001F
    */
   public InterfaceBaseDatosRegistro() 
   {
    
   }
}
