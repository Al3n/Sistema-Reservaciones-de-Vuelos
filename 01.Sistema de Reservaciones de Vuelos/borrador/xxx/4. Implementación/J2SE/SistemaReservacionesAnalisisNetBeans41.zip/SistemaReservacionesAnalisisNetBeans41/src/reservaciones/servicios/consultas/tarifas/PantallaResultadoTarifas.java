//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\servicios\\consultas\\tarifas\\PantallaResultadoTarifas.java

package reservaciones.servicios.consultas.tarifas;


public class PantallaResultadoTarifas 
{
   
   /**
   @roseuid 401EF4CC00EA
    */
   public PantallaResultadoTarifas() 
   {
    
   }
}
