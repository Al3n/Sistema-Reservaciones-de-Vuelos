//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\registro\\tarjeta\\RegistroTarjeta.java

package reservaciones.registro.tarjeta;


public class RegistroTarjeta 
{
   String login;
   String nombre;
   String numero;
   String tipo;
   String fecha;
   
   /**
   @roseuid 401EF4C2035B
    */
   public RegistroTarjeta() 
   {
    
   }
}
