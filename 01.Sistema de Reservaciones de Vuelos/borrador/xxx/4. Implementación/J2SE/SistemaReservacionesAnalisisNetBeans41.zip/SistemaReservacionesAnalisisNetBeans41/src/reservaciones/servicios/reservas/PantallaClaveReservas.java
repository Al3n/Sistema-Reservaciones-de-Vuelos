//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\servicios\\reservas\\PantallaClaveReservas.java

package reservaciones.servicios.reservas;


class PantallaClaveReservas 
{
   
   /**
   @roseuid 401EF4CE03D8
    */
   public PantallaClaveReservas() 
   {
    
   }
}
