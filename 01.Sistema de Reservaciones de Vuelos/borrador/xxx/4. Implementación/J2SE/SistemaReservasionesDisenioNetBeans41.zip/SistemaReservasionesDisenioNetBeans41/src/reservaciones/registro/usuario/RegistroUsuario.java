package reservaciones.registro.usuario;

import reservaciones.dominio.*;

public class RegistroUsuario extends Datos {

    public RegistroUsuario() {
    }
}
