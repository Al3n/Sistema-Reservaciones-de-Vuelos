//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\registro\\usuario\\RegistroUsuario.java

package reservaciones.registro.usuario;


public class RegistroUsuario 
{
   String login;
   String password;
   String nombre;
   String apellido;
   String direccion;
   String colonia;
   String ciudad;
   String pais;
   String CP;
   String telCasa;
   String telOficina;
   String fax;
   String email;
   String rpassword;
   
   /**
   @roseuid 401EF4C402CF
    */
   public RegistroUsuario() 
   {
    
   }
}
