package reservaciones.principal;

import reservaciones.interfaceUsuario.*;
import reservaciones.dominio.*;
import reservaciones.servicios.reservas.*;
import reservaciones.servicios.principal.*;
import reservaciones.registro.usuario.*;
import reservaciones.pantallas.*;
import reservaciones.util.*;
import java.util.*;

public abstract class Manejador {

    protected InterfaceUsuario interfaceUsuario;
    protected Pantalla pantalla;
    protected ManejadorReservas mrs;
    protected ManejadorServicio ms;
    protected ManejadorRegistroUsuario mru;
    protected Manejador mPadre;
    protected String classpath;
    static boolean app_fg = true; // true - app, false - web

public Manejador() {
      classpath = "reservaciones.pantallas"; // Utilerias.getClassPath(this);
}
public Manejador(InterfaceUsuario iu) {
    this();
    interfaceUsuario = iu;
}
public Manejador(InterfaceUsuario iu, boolean fg) {
    this();
    interfaceUsuario = iu;
    app_fg = fg;
}
public Manejador(Manejador m,InterfaceUsuario ui) {
    this(ui);
    mPadre = m;
    if (mPadre != null)
         ms = mPadre.getManejadorServicio();
}
protected Pantalla crearPantalla(String name) {
    System.out.println("Creando: "+classpath+"."+name);
    return interfaceUsuario.crearPantalla(classpath,name);
}
protected void desplegarPantalla(Pantalla p) {
    if (p != null) {
          pantalla = p;
          p.setManejador(this);
          interfaceUsuario.setManejador(this); // p.getManejador()
          interfaceUsuario.desplegarPantalla(p);
    }
    else
          System.out.print("Pantalla Nula");
}

        public ManejadorRegistroUsuario getManejadorRegistroUsuario(){
                return mru;
        }
        // Otras Responsabilidades Publicas
        public ManejadorServicio getManejadorServicio() {
                return ms;
        }
	public Pantalla getPantalla() {
		return pantalla;
	}

        // Contrato 1: Manejar Evento
        public abstract void manejarEvento(String str);
        protected void manejarEventoOfrecerServicio() {
            if (ms != null)
                ms.ofrecerServicio();
            else
                System.out.println("No se ha inicializado el ManejadorServicios");
        }
        protected void manejarEventosAdicionales(String str) {
                if (str.equals("Servicios"))
                    manejarEventoOfrecerServicio();
                else if (str.equals("Salir"))
                    manejarEventoSalir();
                else
                    System.out.println("Error en pantalla: "+this+", Evento: "+str);
        }
        protected void manejarEventoSalir() {
            if (app_fg == true)
		System.exit(0);
            else
            	interfaceUsuario.inicializar();
        }
        public void setManejadorRegistroUsuario(ManejadorRegistroUsuario m){
                mru = m;
        }
        public void setManejadorServicio(ManejadorServicio m) {
                ms = m;
        }
	public void setPantalla(Pantalla p) {
		pantalla = p;
	}
}
