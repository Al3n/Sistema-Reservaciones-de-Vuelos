//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\registro\\tarjeta\\PantallaCrearRegTarjeta.java

package reservaciones.registro.tarjeta;


public class PantallaCrearRegTarjeta 
{
   
   /**
   @roseuid 401EF4C20119
    */
   public PantallaCrearRegTarjeta() 
   {
    
   }
}
