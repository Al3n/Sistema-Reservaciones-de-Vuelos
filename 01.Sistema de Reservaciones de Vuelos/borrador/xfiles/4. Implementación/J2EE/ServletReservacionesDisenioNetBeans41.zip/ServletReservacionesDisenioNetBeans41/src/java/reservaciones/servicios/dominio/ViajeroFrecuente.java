package reservaciones.servicios.dominio;


public class ViajeroFrecuente 
{
   public ViajeroFrecuente() 
   {
    
   }
}
