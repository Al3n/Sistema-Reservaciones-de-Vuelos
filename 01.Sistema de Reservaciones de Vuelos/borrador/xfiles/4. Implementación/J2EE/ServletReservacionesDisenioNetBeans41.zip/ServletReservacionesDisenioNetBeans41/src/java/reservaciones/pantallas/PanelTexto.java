/*
 * PanelComboBox.java
 *
 * Created on 31 de mayo de 2005, 01:43 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package reservaciones.pantallas;

import reservaciones.dominio.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 *
 * @author alfredow
 */
public class PanelTexto extends PanelData {
   public PanelTexto(JPanel p,String str, int length){
      super(p,str);
      comp = new JTextField(length);
      comp.setName(name);
      p.add(comp);
   }
   public PanelTexto(JTextField jc){
       super(jc);
   }

}