//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\servicios\\consultas\\estado\\ManejadorConsultaEstado.java

package reservaciones.servicios.consultas.estado;


class ManejadorConsultaEstado 
{
   
   /**
   @roseuid 401EF4C80128
    */
   public ManejadorConsultaEstado() 
   {
    
   }
}
