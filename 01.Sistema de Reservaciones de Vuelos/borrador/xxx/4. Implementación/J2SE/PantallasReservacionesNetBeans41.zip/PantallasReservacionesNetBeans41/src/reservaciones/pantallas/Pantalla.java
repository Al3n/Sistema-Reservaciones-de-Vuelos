package reservaciones.pantallas;

class Pantalla {

  protected void borrarPantalla() {}
  protected void refrescarPantalla() {}
  protected void crearPantalla() {}
  
  protected Pantalla manejarEvento(String str) { return this; }
}
