//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\servicios\\reservas\\PantallaRecordReservaVuelos.java

package reservaciones.servicios.reservas;


public class PantallaRecordReservaVuelos 
{
   
   /**
   @roseuid 401EF4CF0186
    */
   public PantallaRecordReservaVuelos() 
   {
    
   }
}
