package reservaciones.servicios.dominio;


public class Aerolinea 
{
   
   public Aerolinea() 
   {
    
   }
}