package reservaciones.servicios.dominio;


public class Reservacion 
{
   public Reservacion() 
   {
    
   }
}
