/*
 * ResultadoTarifa.java
 *
 * Created on 17 de febrero de 2004, 06:06 PM
 */

package reservaciones.servicios.consultas.tarifas;

/**
 *
 * @author  Administrador
 */
public class ResultadoTarifa {
    
    /** Creates a new instance of ResultadoTarifa */
    public ResultadoTarifa() {
    }
    
}
