

package reservaciones.servicios.dominio;

import reservaciones.dominio.*;

public class Vuelo extends Datos
{
   public Vuelo() 
   {
        agregarAtributo("id","",true);
        agregarAtributo("origen","",true);
    	agregarAtributo("destino","",true);
   }
}
