package reservaciones.interfaceUsuarioServlet;

import reservaciones.interfaceUsuario.*;

import reservaciones.principal.*;
import reservaciones.dominio.*;
import reservaciones.util.*;

public class InterfaceUsuarioBean extends InterfaceUsuario
{
    private String showPantalla;

    private ReservacionesServlet servlet;

    public InterfaceUsuarioBean() {
        inicializar();
    }
  public Pantalla crearPantalla(String classpath,String classname) {
    pantalla = (Pantalla) Utilerias.instanciarClase("reservaciones.interfaceUsuario.Pantalla");
    pantalla.setInterfaceUsuario(this);
    pantalla.escribirNombre(classname);
    return pantalla;
  }
  public void desplegarPantalla(String str) {
    showPantalla = str + ".jsp";
  }
  public void desplegarPantalla(Pantalla p) {
    if (p != null)
        pantalla = p;

    showPantalla = pantalla.leerNombre() + ".jsp";
  }
public ReservacionesServlet getServlet() {
	return servlet;
}

public String getShowPantalla() {
	return showPantalla;
}

public void inicializar() {
	manejador = new ManejadorPrincipal(this,false); // false - servlet
}

public void setServlet(ReservacionesServlet rs) {
	servlet = rs;
}

}
