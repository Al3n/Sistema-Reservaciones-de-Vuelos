//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\registro\\tarjeta\\PantallaObtenerRegTarjeta.java

package reservaciones.registro.tarjeta;


public class PantallaObtenerRegTarjeta 
{
   
   /**
   @roseuid 401EF4C201E4
    */
   public PantallaObtenerRegTarjeta() 
   {
    
   }
}
