//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\principal\\PantallaPrincipal.java

package reservaciones.principal;


public class PantallaPrincipal 
{
   
   /**
   @roseuid 401EF4BF03C8
    */
   public PantallaPrincipal() 
   {
    
   }
}
