//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\servicios\\consultas\\ManejadorConsultas.java

package reservaciones.servicios.consultas;


public class ManejadorConsultas 
{
   
   /**
   @roseuid 401EF4C602FD
    */
   public ManejadorConsultas() 
   {
    
   }
}
