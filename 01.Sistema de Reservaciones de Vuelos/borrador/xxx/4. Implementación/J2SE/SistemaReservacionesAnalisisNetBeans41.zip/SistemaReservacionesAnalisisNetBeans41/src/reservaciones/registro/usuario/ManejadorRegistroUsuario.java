//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\registro\\usuario\\ManejadorRegistroUsuario.java

package reservaciones.registro.usuario;


public class ManejadorRegistroUsuario 
{
   
   /**
   @roseuid 401EF4C30399
    */
   public ManejadorRegistroUsuario() 
   {
    
   }
}
