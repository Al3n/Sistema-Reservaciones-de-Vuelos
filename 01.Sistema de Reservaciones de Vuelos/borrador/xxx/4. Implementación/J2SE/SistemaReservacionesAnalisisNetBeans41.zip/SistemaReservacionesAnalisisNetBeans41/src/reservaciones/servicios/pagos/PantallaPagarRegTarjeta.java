//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\servicios\\pagos\\PantallaPagarRegTarjeta.java

package reservaciones.servicios.pagos;


public class PantallaPagarRegTarjeta 
{
   
   /**
   @roseuid 401EF4CD0203
    */
   public PantallaPagarRegTarjeta() 
   {
    
   }
}
