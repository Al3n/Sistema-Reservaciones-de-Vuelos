package reservaciones.servicios.interfaceBD;

import reservaciones.servicios.consultas.estado.*;
import reservaciones.servicios.consultas.horarios.*;
import reservaciones.servicios.consultas.tarifas.*;
import reservaciones.servicios.dominio.*;
import reservaciones.registro.tarjeta.*;
import reservaciones.dominio.*;

import reservaciones.servicios.interfaceBD.*;

import java.sql.*;
import java.util.*;

public class InterfaceBaseDatosReserva extends InterfaceReserva
{       
   public InterfaceBaseDatosReserva()  { 
   }
   // Contrato 1: Consultar Informacion
   public boolean consultarHorario(/*ConsultaHorario s*/){
       return true;
   }
   public boolean consultarTarifas(/*ConsultaTarifa s*/){
       return true;
   }
   public boolean consultarEstado(/*ConsultaEstado s*/){
       return true;
   }
   // Contrato 2: Hacer Reservacion
   public boolean crearReserva(/*Reservacion r*/) {
       return true;
   }
   public boolean obtenerReserva(/*Reservacion r*/) {
       return true;
   }
   public boolean actualizarReserva(/*Reservacion r*/) {
       return true;
   }
   public boolean eliminarReserva(/*Reservacion r*/) {
       return true;
   }
   // Contrato 3: Pagar Reservacion
   public boolean pagarReserva(/*Reservacion r*/RegistroTarjeta rt) {
       return true;
   }
   public boolean eliminarReserva(/*Reservacion r*/RegistroTarjeta rt) {
       return true;
   }
}
