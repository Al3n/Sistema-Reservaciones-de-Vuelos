//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\registro\\usuario\\PantallaObtenerRegUsuario.java

package reservaciones.registro.usuario;


public class PantallaObtenerRegUsuario 
{
   
   /**
   @roseuid 401EF4C40148
    */
   public PantallaObtenerRegUsuario() 
   {
    
   }
}
