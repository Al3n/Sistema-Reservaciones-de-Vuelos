//Source file: C:\\ALFREDO\\alfredo\\Libro\\Reservaciones\\SistemaReservacionesAnalisis\\reservaciones\\servicios\\consultas\\horarios\\PantallaResultadoHorarios.java

package reservaciones.servicios.consultas.horarios;


public class PantallaResultadoHorarios 
{
   
   /**
   @roseuid 401EF4CA01E4
    */
   public PantallaResultadoHorarios() 
   {
    
   }
}
