

package reservaciones.servicios.dominio;

import reservaciones.dominio.*;

public class Vuelos extends Datos
{
   public Vuelos() 
   {
   }
}
